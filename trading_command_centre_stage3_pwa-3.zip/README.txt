TRADING COMMAND CENTRE — STAGE 3 PWA PACKAGE

This is a demo-only installable web-app prototype.
It does NOT connect to a broker or MT5, request trading credentials, or place trades.

FILES
- index.html: app screen
- manifest.webmanifest: install/app metadata
- service-worker.js: offline cache
- icons/: app icons

IMPORTANT INSTALL NOTE
For Android to offer 'Install app' / 'Add to Home screen' as a proper PWA,
these files must be hosted from an HTTPS website. Opening index.html directly
from the phone's Downloads folder will let you preview it, but usually will not
enable full PWA installation or offline service-worker support.

No paid hosting is required in principle, but a free HTTPS static host is needed.
